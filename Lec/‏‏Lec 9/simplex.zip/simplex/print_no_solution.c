// print_no_solution.c 


#include <stdio.h>
#include "simplex.h"

void print_no_solution()
{

  printf("System A has NO solution\n");

} // print_no_solution
