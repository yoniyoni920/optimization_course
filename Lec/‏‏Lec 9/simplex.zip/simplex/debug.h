// debug.h

extern void print_simplex_params(double *A[],  double *A_aux[],
double c[], double b[], int n,
int m, double *B[], double *BID[],
double *D[],  int basis[], int d[], double cb[], double cd[]);

